import React, { useEffect, useState } from 'react';
import QueryEditor from './components/QueryEditor';
import ResultsTable from './components/ResultsTable';
import TablesPanel from './components/TablesPanel';
import Login from './components/Login';

const API_BASE = process.env.REACT_APP_API_BASE || 'http://localhost:8000/api';

function App(){
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [tables, setTables] = useState([]);
  const [selectedTableInfo, setSelectedTableInfo] = useState(null);
  useEffect(()=> {
    fetch(API_BASE + '/tables/')
      .then(r=>r.json())
      .then(data=> setTables(data.tables || []))
      .catch(e=> console.error(e));
  }, []);
  const runQuery = async (query) => {
    setLoading(true);
    setResults(null);
    setSelectedTableInfo(null);
    try{
      const res = await fetch(API_BASE + '/query/', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({query})
      });
      const data = await res.json();
      setResults(data);
    }catch(e){
      setResults({error: e.message});
    }
    setLoading(false);
  };
  const showTable = (name) => {
    fetch(API_BASE + '/table/' + name + '/')
      .then(r=>r.json())
      .then(data=> setSelectedTableInfo(data))
      .catch(e=> console.error(e));
  };
  return (
    <div className="app-shell">
      <aside className="sidebar card">
        <h3>Database</h3>
        <p className="small-muted">Available tables</p>
        <TablesPanel tables={tables} onSelect={showTable} />
        <div style={{marginTop:18}}>
          <Login apiBase={API_BASE} onLogin={()=>{}} />
        </div>
      </aside>
      <main className="main">
        <div className="card header">
          <div>
            <div className="title">SQL Runner</div>
            <div className="small-muted">Run SQL queries against the provided SQLite sample DB</div>
          </div>
          <div className="small-muted">Connected to local sqlite</div>
        </div>

        <div className="card editor">
          <QueryEditor onRun={runQuery} loading={loading} />
        </div>

        <div className="card results-wrap">
          <ResultsTable result={results} selectedTableInfo={selectedTableInfo} loading={loading}/>
        </div>
      </main>
    </div>
  );
}
export default App;
