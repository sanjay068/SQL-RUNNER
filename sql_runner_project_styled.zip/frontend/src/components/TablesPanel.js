import React from 'react';
export default function TablesPanel({tables, onSelect}){
  return (
    <ul className="table-list" style={{marginTop:10}}>
      {tables.map(t=>(
        <li key={t} onClick={()=>onSelect(t)}>
          <span>{t}</span>
          <small className="small-muted">preview</small>
        </li>
      ))}
    </ul>
  );
}
