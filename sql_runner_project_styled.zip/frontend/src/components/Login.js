import React, {useState} from 'react';
export default function Login({apiBase, onLogin}){
  const [u, setU] = useState('');
  const [p, setP] = useState('');
  const [msg, setMsg] = useState('');
  const doLogin = async () => {
    try{
      const res = await fetch(apiBase + '/login/', {
        method:'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({username: u, password: p})
      });
      const data = await res.json();
      if(data.message){
        setMsg('Logged in');
        onLogin && onLogin();
      } else {
        setMsg('Login failed');
      }
    }catch(e){
      setMsg('Error');
    }
  };
  return (
    <div style={{marginTop:8}}>
      <div style={{display:'flex',gap:8}}>
        <input placeholder="username" value={u} onChange={e=>setU(e.target.value)} style={{flex:1,padding:8,borderRadius:8,border:'1px solid rgba(255,255,255,0.04)',background:'transparent',color:'#e6eef6'}} />
        <input placeholder="password" type="password" value={p} onChange={e=>setP(e.target.value)} style={{flex:1,padding:8,borderRadius:8,border:'1px solid rgba(255,255,255,0.04)',background:'transparent',color:'#e6eef6'}} />
      </div>
      <div style={{display:'flex',gap:8,marginTop:8}}>
        <button className="btn" onClick={doLogin}>Login</button>
        <button className="btn secondary" onClick={()=>{setU('');setP('');setMsg('')}}>Reset</button>
      </div>
      <div style={{marginTop:8}} className="small-muted">{msg}</div>
    </div>
  );
}
