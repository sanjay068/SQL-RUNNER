import React, { useState } from 'react';
export default function QueryEditor({onRun, loading}){
  const [q, setQ] = useState('SELECT * FROM Customers;');
  const quick = (example) => setQ(example);
  return (
    <div>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <div style={{fontWeight:600}}>Query</div>
        <div className="small-muted">Examples: <button className="btn secondary" style={{padding:'6px 8px'}} onClick={()=>quick('SELECT * FROM Customers;')}>Customers</button> <button className="btn secondary" style={{padding:'6px 8px'}} onClick={()=>quick('SELECT name, email FROM Customers WHERE country = \'India\';')}>India</button></div>
      </div>
      <textarea className="textarea" value={q} onChange={e=>setQ(e.target.value)} rows={8} />
      <div className="controls" style={{marginTop:8}}>
        <button className="btn" onClick={()=>onRun(q)} disabled={loading}>{loading ? 'Running...' : 'Run Query'}</button>
        <button className="btn secondary" onClick={()=>{ setQ('') }}>Clear</button>
        <div style={{marginLeft:'auto'}} className="small-muted">Results will appear below</div>
      </div>
    </div>
  );
}
