import React from 'react';
export default function ResultsTable({result, selectedTableInfo}){
  if(!result && !selectedTableInfo){
    return <div className="msg">Select a table or run a query to see results.</div>;
  }
  if(result && result.error) return <div className="error">Error: {result.error}</div>;
  if(selectedTableInfo){
    return (
      <div>
        <h4>Schema</h4>
        <div style={{display:'grid',gridTemplateColumns:'1fr 2fr',gap:8}}>
          <div className="small-muted" style={{fontWeight:600}}>Columns</div>
          <div className="small-muted" style={{fontWeight:600}}>Sample rows</div>
        </div>
        <pre style={{whiteSpace:'pre-wrap',marginTop:8}}>{JSON.stringify(selectedTableInfo.schema, null, 2)}</pre>
        <h4 style={{marginTop:12}}>Sample rows</h4>
        <pre style={{whiteSpace:'pre-wrap'}}>{JSON.stringify(selectedTableInfo.sample_rows, null, 2)}</pre>
      </div>
    );
  }
  if(result && result.rows){
    return (
      <div>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <h4 style={{margin:0}}>Results ({result.rows.length})</h4>
          <div className="small-muted">Columns: {result.columns.length}</div>
        </div>
        <div style={{overflow:'auto',marginTop:10}}>
          <table className="table">
            <thead>
              <tr>{result.columns.map((c,i)=><th key={i}>{c}</th>)}</tr>
            </thead>
            <tbody>
              {result.rows.map((r,idx)=>
                <tr key={idx}>
                  {result.columns.map((c,i)=><td key={i}>{r[c] !== null ? String(r[c]) : ''}</td>)}
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
  if(result && result.message){
    return <div className="msg">Message: {result.message} <span className="small-muted">(affected_rows: {result.affected_rows})</span></div>
  }
  return <div className="msg">No results</div>;
}
