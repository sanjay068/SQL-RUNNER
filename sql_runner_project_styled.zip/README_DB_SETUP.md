# Create sample SQLite database (sql_runner.db)

A sample SQL file (example_sql_runner.sql) is included. To create `sql_runner.db`:

1. From the `backend` directory:
   ```
   sqlite3 sql_runner.db < ../example_sql_runner.sql
   ```
2. Verify:
   ```
   sqlite3 sql_runner.db
   sqlite> .tables
   sqlite> SELECT * FROM Customers LIMIT 5;
   sqlite> .exit
   ```

The provided SQL creates `Customers`, `Orders`, and `Shippings` with example data.

