-- Example tables for SQL Runner
CREATE TABLE Customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT,
    country TEXT
);

CREATE TABLE Orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER,
    product TEXT,
    amount REAL,
    order_date TEXT,
    FOREIGN KEY(customer_id) REFERENCES Customers(id)
);

CREATE TABLE Shippings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER,
    shipped_date TEXT,
    carrier TEXT,
    status TEXT,
    FOREIGN KEY(order_id) REFERENCES Orders(id)
);

INSERT INTO Customers (name, email, country) VALUES
('Alice', 'alice@example.com', 'USA'),
('Bob', 'bob@example.com', 'UK'),
('Carlos', 'carlos@example.com', 'India'),
('Diana', 'diana@example.com', 'Canada');

INSERT INTO Orders (customer_id, product, amount, order_date) VALUES
(1, 'Laptop', 1200.50, '2024-01-10'),
(2, 'Keyboard', 45.00, '2024-02-05'),
(1, 'Mouse', 25.00, '2024-03-15'),
(3, 'Monitor', 300.00, '2024-04-01');

INSERT INTO Shippings (order_id, shipped_date, carrier, status) VALUES
(1, '2024-01-12', 'DHL', 'Delivered'),
(2, '2024-02-07', 'UPS', 'In Transit'),
(3, '2024-03-18', 'FedEx', 'Delivered'),
(4, '2024-04-03', 'DHL', 'Pending');

