# SQL Runner - Full Stack Assignment (React + Django)

This is a complete scaffold for the **SQL Runner** assignment:
- Frontend: React (create-react-app style)
- Backend: Django REST-style API (uses Python sqlite3 for executing queries)
- SQLite database file location: `backend/sql_runner.db` (not included; instructions below)
- Dockerfiles and `docker-compose.yml` are provided as a bonus.

## What is included
- `frontend/` — React app (components: QueryEditor, ResultsTable, TablesPanel, Login)
- `backend/` — Django project `sqlrunner_project` + app `api`
  - REST endpoints:
    - `POST /api/query/` — execute arbitrary SQL (returns JSON or error)
    - `GET  /api/tables/` — list table names
    - `GET  /api/table/<table_name>/` — schema + sample rows (first 5)
    - `POST /api/login/` — basic username/password (Django auth)
    - `GET  /api/recent/` — recent queries for logged in user (bonus)
- `docker-compose.yml` — runs backend and frontend (optional)
- `README_DB_SETUP.md` — instructions to create `sql_runner.db` with sample tables

## Quick start (development, no Docker)
1. Backend
   - Create a Python virtualenv and install requirements:
     ```
     cd backend
     python -m venv venv
     source venv/bin/activate
     pip install -r requirements.txt
     ```
   - Run migrations and create a superuser:
     ```
     python manage.py migrate
     python manage.py createsuperuser
     ```
   - Create/restore SQLite DB `sql_runner.db` in `backend/` as explained in `README_DB_SETUP.md`.
   - Run server:
     ```
     python manage.py runserver
     ```
2. Frontend
   - Install and start:
     ```
     cd frontend
     npm install
     npm start
     ```
   - Open http://localhost:3000 and the frontend will call backend on http://localhost:8000 by default.

## Security note
This project executes raw SQL provided by users against a local sample SQLite database for the assignment purpose. **Do not** deploy this to a public production environment without proper safeguards (SQL sandboxing, query limits, authentication, roles, etc).

