from django.db import models
from django.contrib.auth.models import User
class RecentQuery(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    query_text = models.TextField()
    executed_at = models.DateTimeField(auto_now_add=True)
    success = models.BooleanField(default=True)
    error_message = models.TextField(blank=True, null=True)
    def __str__(self):
        return f'{self.user} - {self.executed_at}'
