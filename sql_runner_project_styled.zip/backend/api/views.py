import sqlite3
import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from .models import RecentQuery
from .serializers import RecentQuerySerializer
from django.views.decorators.http import require_http_methods

DB_PATH = 'sql_runner.db'  # relative to backend/ - Django settings uses BASE_DIR/sql_runner.db

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

@require_http_methods(['GET'])
def list_tables(request):
    try:
        conn = get_conn()
        cur = conn.cursor()
        cur.execute("""SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';""")
        tables = [row['name'] for row in cur.fetchall()]
        conn.close()
        return JsonResponse({'tables': tables})
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

@require_http_methods(['GET'])
def table_info(request, tablename):
    try:
        conn = get_conn()
        cur = conn.cursor()
        # schema
        cur.execute(f"PRAGMA table_info('{tablename}');")
        cols = [{'cid': r['cid'], 'name': r['name'], 'type': r['type'], 'notnull': r['notnull'], 'dflt_value': r['dflt_value']} for r in cur.fetchall()]
        # sample rows
        cur.execute(f"SELECT * FROM '{tablename}' LIMIT 5;")
        rows = [dict(r) for r in cur.fetchall()]
        conn.close()
        return JsonResponse({'schema': cols, 'sample_rows': rows})
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

@csrf_exempt
@require_http_methods(['POST'])
def run_query(request):
    try:
        body = json.loads(request.body.decode('utf-8'))
        query = body.get('query', '')
        if not query:
            return JsonResponse({'error': 'No query provided'}, status=400)
        conn = get_conn()
        cur = conn.cursor()
        cur.execute(query)
        # If SELECT, fetch rows
        if query.strip().lower().startswith('select'):
            cols = [description[0] for description in cur.description] if cur.description else []
            rows = [dict(zip(cols, row)) for row in cur.fetchall()]
            # record recent query if user authenticated
            user = request.user if request.user.is_authenticated else None
            if user:
                RecentQuery.objects.create(user=user, query_text=query, success=True)
            return JsonResponse({'columns': cols, 'rows': rows})
        else:
            conn.commit()
            affected = cur.rowcount
            return JsonResponse({'message': 'Query executed', 'affected_rows': affected})
    except Exception as e:
        # store failed query if possible
        try:
            user = request.user if request.user.is_authenticated else None
            if user:
                RecentQuery.objects.create(user=user, query_text=query if 'query' in locals() else '', success=False, error_message=str(e))
        except:
            pass
        return JsonResponse({'error': str(e)}, status=400)

@csrf_exempt
@require_http_methods(['POST'])
def basic_login(request):
    try:
        data = json.loads(request.body.decode('utf-8'))
        username = data.get('username')
        password = data.get('password')
        user = authenticate(username=username, password=password)
        if user:
            login(request, user)
            return JsonResponse({'message': 'logged_in'})
        else:
            return JsonResponse({'error': 'invalid credentials'}, status=401)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=400)

@require_http_methods(['GET'])
def recent_queries(request):
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'authentication required'}, status=401)
    qs = RecentQuery.objects.filter(user=request.user).order_by('-executed_at')[:20]
    ser = RecentQuerySerializer(qs, many=True)
    return JsonResponse({'recent': ser.data})
