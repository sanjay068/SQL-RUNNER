from django.urls import path
from . import views
urlpatterns = [
    path('tables/', views.list_tables, name='list_tables'),
    path('table/<str:tablename>/', views.table_info, name='table_info'),
    path('query/', views.run_query, name='run_query'),
    path('recent/', views.recent_queries, name='recent_queries'),
    path('login/', views.basic_login, name='basic_login'),
]
