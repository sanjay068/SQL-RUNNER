from django.contrib import admin
from .models import RecentQuery
admin.site.register(RecentQuery)
