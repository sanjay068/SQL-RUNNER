from rest_framework import serializers
from .models import RecentQuery
class RecentQuerySerializer(serializers.ModelSerializer):
    class Meta:
        model = RecentQuery
        fields = ['id','user','query_text','executed_at','success','error_message']
